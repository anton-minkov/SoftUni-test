package myPack;

/**
 * Created by anton on 16-3-20.
 */
public class PrintCharacters {
    public static void main(String[] args) {
        char c = 'a';
        for (int i=0;i < 26; i++){
            System.out.print(c++ +" ");
        }
    }
}
