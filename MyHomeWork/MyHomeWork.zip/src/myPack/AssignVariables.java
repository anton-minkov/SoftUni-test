package myPack;

/**
 * Created by anton on 16-3-20.
 */
public class AssignVariables {
    public static void main(String[] args) {
        byte firtsNumber =127;
        short secondNumber =32767;
        int tirdNumber =2000000000;
        long l = 919827112351L;
        char c = 'c';
        boolean b = false;
        float f =0.5f;
        double d = 0.1234567891011;
        String text = "Palo Alto, CA";
        //System.out.println(tirdNumber);
    }
}
